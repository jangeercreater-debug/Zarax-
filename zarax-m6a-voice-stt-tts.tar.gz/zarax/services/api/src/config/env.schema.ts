import {
  baseEnvSchema,
  eventBusEnvSchema,
  jwtEnvSchema,
  llmProvidersEnvSchema,
  observabilityEnvSchema,
  postgresEnvSchema,
  redisEnvSchema,
} from '@zarax/shared-config';
import type { z } from 'zod';

export const apiEnvSchema = baseEnvSchema
  .merge(postgresEnvSchema)
  .merge(redisEnvSchema)
  .merge(jwtEnvSchema)
  .merge(eventBusEnvSchema)
  .merge(observabilityEnvSchema)
  .merge(llmProvidersEnvSchema);

export type ApiEnv = z.infer<typeof apiEnvSchema>;
